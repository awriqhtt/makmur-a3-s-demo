module.exports = {
  reactStrictMode: true,
  experimental: { serverComponentsExternalPackages: ["puppeteer"] },
};
