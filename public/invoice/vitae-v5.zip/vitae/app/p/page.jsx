import Portfolio from "../../components/Portfolio";
import { DEF } from "../../lib/data";
import data from "../../data/portfolio.json";

/* Halaman PUBLIK. Isi dari data/portfolio.json (hasil "Unduh portfolio.json").
   Ganti file itu, lalu deploy ulang. Selama kosong, tampil data contoh. */
const cv = data.profile
  ? { ...DEF, ...data, profile: { ...DEF.profile, ...data.profile }, layout: { ...DEF.layout, ...data.layout } }
  : DEF;

export const metadata = { title: `${cv.profile.name} - Portofolio`, description: cv.profile.title };

export default function PublicPortfolio() {
  return <Portfolio cv={cv} />;
}
