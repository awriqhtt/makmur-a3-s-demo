"use client";
import Link from "next/link";
import { useState } from "react";
import { askAi } from "../../lib/ai";
import { cvText } from "../../lib/text";
import { useCv } from "../../lib/useCv";

const btn = "rounded-md border border-neutral-300 bg-white px-2.5 py-1.5 text-[13px] font-medium hover:border-teal-600 dark:border-neutral-700 dark:bg-neutral-800";
const box = "mt-1 w-full rounded-md border border-neutral-300 bg-white px-2.5 py-1.5 text-sm text-neutral-900 dark:border-neutral-700 dark:bg-neutral-800 dark:text-neutral-100";

export default function CoverLetter() {
  const { cv, name, upd, status } = useCv();
  const [busy, setBusy] = useState(false);
  const l = cv.letter, p = cv.profile, e0 = cv.exp[0];
  const today = new Date().toLocaleDateString("id-ID", { day: "numeric", month: "long", year: "numeric" });

  const template = () => upd("letter.body",
    `Saya tertarik melamar posisi ${l.role || "[posisi]"} di ${l.company || "[perusahaan]"}. ${p.summary}\n\n` +
    `Saat ini saya bekerja sebagai ${e0?.role || "[posisi]"} di ${e0?.org || "[perusahaan]"}. Pengalaman tersebut membekali saya dengan [sebutkan keahlian yang relevan dengan lowongan].\n\n` +
    `Saya berharap dapat berdiskusi lebih lanjut mengenai kontribusi yang bisa saya berikan. Terima kasih atas waktu dan perhatian Bapak/Ibu.`);

  const ai = async () => {
    setBusy(true);
    try {
      const ctx = `Perusahaan: ${l.company || "-"}. Posisi: ${l.role || "-"}. Lowongan: ${l.jd || "-"}`;
      upd("letter.body", await askAi("cover", cvText(cv), ctx));
    } catch (e) { alert(e.message); }
    setBusy(false);
  };

  return (
    <>
      <div className="flex flex-wrap items-center gap-2 border-b border-neutral-300 bg-neutral-50 px-3.5 py-2.5 dark:border-neutral-800 dark:bg-neutral-900 print:hidden">
        <h1 className="text-[17px] font-semibold">Surat lamaran</h1>
        <span className="text-xs text-neutral-500">Data dari: {name}</span>
        <span className="mr-auto text-xs text-neutral-500">{status}</span>
        <Link href="/" className={btn}>Kembali ke CV</Link>
        <button className="rounded-md bg-teal-700 px-3 py-1.5 text-[13px] font-medium text-white hover:bg-teal-800" onClick={() => window.print()}>Cetak / PDF</button>
      </div>
      <main className="md:grid md:h-[calc(100vh-53px)] md:grid-cols-[minmax(320px,420px)_1fr] print:block">
        <div className="overflow-auto border-r border-neutral-300 bg-neutral-50 p-3.5 dark:border-neutral-800 dark:bg-neutral-900 print:hidden">
          {[["company", "Perusahaan"], ["role", "Posisi dilamar"], ["manager", "Ditujukan kepada (opsional)"]].map(([k, t]) => (
            <label key={k} className="mt-2 block text-xs text-neutral-500">{t}
              <input className={box} value={l[k]} onChange={(e) => upd("letter." + k, e.target.value)} />
            </label>
          ))}
          <label className="mt-2 block text-xs text-neutral-500">Deskripsi lowongan (opsional, untuk AI)
            <textarea className={box + " min-h-[90px]"} value={l.jd} onChange={(e) => upd("letter.jd", e.target.value)} />
          </label>
          <label className="mt-2 block text-xs text-neutral-500">Isi surat
            <textarea className={box + " min-h-[220px]"} value={l.body} onChange={(e) => upd("letter.body", e.target.value)} />
          </label>
          <div className="mt-2 flex gap-2">
            <button className={btn} onClick={template}>Isi template</button>
            <button className={btn + " border-teal-600"} disabled={busy} onClick={ai}>{busy ? "Memproses..." : "Tulis dengan AI"}</button>
          </div>
        </div>
        <div className="overflow-auto p-3 md:p-6 print:p-0">
          <div id="sheet" className="mx-auto min-h-[297mm] w-[210mm] max-w-full bg-white px-[22mm] py-[20mm] text-[11pt] leading-relaxed text-neutral-800 shadow-xl">
            <div className="font-bold">{p.name}</div>
            <div className="text-[0.9em] text-neutral-500">{[p.phone, p.email, p.location].filter(Boolean).join(" | ")}</div>
            <div className="mt-6">{today}</div>
            <div className="mt-4">
              Yth. {l.manager || "Tim Rekrutmen"}<br />{l.company}
            </div>
            <div className="mt-4 font-semibold">Perihal: Lamaran posisi {l.role || "..."}</div>
            <p className="mt-4">Dengan hormat,</p>
            <div className="mt-3 whitespace-pre-wrap">{l.body || "Isi surat akan tampil di sini."}</div>
            <p className="mt-6">Hormat saya,</p>
            <p className="mt-12 font-bold">{p.name}</p>
          </div>
        </div>
      </main>
    </>
  );
}
