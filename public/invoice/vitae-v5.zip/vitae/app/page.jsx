"use client";
import Link from "next/link";
import { useEffect, useRef, useState } from "react";
import AtsChecker from "../components/AtsChecker";
import Editor from "../components/Editor";
import Settings from "../components/Settings";
import Sheet from "../components/Sheet";
import { DEF } from "../lib/data";
import { useCv } from "../lib/useCv";

const btn = "rounded-md border border-neutral-300 bg-white px-2.5 py-1.5 text-[13px] font-medium hover:border-teal-600 dark:border-neutral-700 dark:bg-neutral-800";
const tabCls = (on) => "flex-1 rounded-md border px-3 py-1.5 text-[13px] font-medium " + (on ? "border-teal-700 bg-teal-700 text-white" : "border-neutral-300 dark:border-neutral-700");

export default function Page() {
  const { store, cv, name, setCv, upd, act, status, undo, redo, canUndo, canRedo } = useCv();
  const [tab, setTab] = useState("edit");
  const [panel, setPanel] = useState("isi");
  const fileRef = useRef(null);
  const [pdfBusy, setPdfBusy] = useState(false);

  const downloadPdf = async () => {
    setPdfBusy(true);
    try {
      const r = await fetch("/api/pdf", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(cv) });
      if (!r.ok) throw new Error((await r.json()).error || "Gagal membuat PDF");
      const a = document.createElement("a");
      a.href = URL.createObjectURL(await r.blob());
      a.download = `${name.replace(/[^\w-]+/g, "_")}.pdf`;
      a.click();
    } catch (e) { alert(e.message); }
    setPdfBusy(false);
  };

  useEffect(() => {
    const onKey = (e) => {
      if (!(e.ctrlKey || e.metaKey)) return;
      const k = e.key.toLowerCase();
      if (k === "z" && !e.shiftKey) { e.preventDefault(); undo(); }
      else if (k === "y" || (k === "z" && e.shiftKey)) { e.preventDefault(); redo(); }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [undo, redo]);

  const exportJson = () => {
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([JSON.stringify(store, null, 2)], { type: "application/json" }));
    a.download = "cv-data.json";
    a.click();
  };

  const importJson = (e) => {
    const f = e.target.files[0];
    if (!f) return;
    const r = new FileReader();
    r.onload = () => {
      try {
        const d = JSON.parse(r.result);
        if (d.items?.length) { if (confirm("Ganti semua CV dengan isi file ini?")) act.replace(d); }
        else if (d.profile) act.create(f.name.replace(/\.json$/i, ""), d);
        else throw new Error("format");
      } catch { alert("File JSON tidak valid. Pakai file hasil Simpan JSON."); }
    };
    r.readAsText(f);
    e.target.value = "";
  };

  const create = () => { const n = prompt("Nama CV baru:", "CV baru"); if (n) act.create(n, DEF); };
  const dup = () => act.create(name + " (salinan)", cv);
  const ren = () => { const n = prompt("Nama CV:", name); if (n) act.rename(n); };
  const del = () => { if (store.items.length < 2) return alert("Minimal harus ada satu CV."); if (confirm(`Hapus "${name}"?`)) act.remove(); };
  const reset = () => confirm("Kembalikan CV ini ke data contoh?") && setCv(structuredClone(DEF));

  return (
    <>
      <div className="flex flex-wrap items-center gap-2 border-b border-neutral-300 bg-neutral-50 px-3.5 py-2.5 dark:border-neutral-800 dark:bg-neutral-900 print:hidden">
        <Link href="/" className="flex items-center gap-2"><img src="/logo-mark.svg" alt="" className="h-7 w-7" /><h1 className="text-[17px] font-semibold">Vitae</h1></Link>
        <select aria-label="Pilih CV" className={btn} value={store.active} onChange={(e) => act.pick(e.target.value)}>
          {store.items.map((i) => <option key={i.id} value={i.id}>{i.name}</option>)}
        </select>
        <button className={btn} onClick={create}>+ Baru</button>
        <button className={btn} onClick={dup}>Duplikat</button>
        <button className={btn} onClick={ren}>Ganti nama</button>
        <button className={btn} onClick={del}>Hapus</button>
        <button className={btn + " disabled:opacity-40"} disabled={!canUndo} onClick={undo} title="Ctrl+Z">Undo</button>
        <button className={btn + " disabled:opacity-40"} disabled={!canRedo} onClick={redo} title="Ctrl+Y">Redo</button>
        <span className="mr-auto text-xs text-neutral-500">{status}</span>
        <Link href="/cover-letter" className={btn}>Surat lamaran</Link>
        <Link href="/portfolio" className={btn}>Portofolio</Link>
        <button className={btn} onClick={() => fileRef.current.click()}>Import</button>
        <input ref={fileRef} type="file" accept="application/json" hidden onChange={importJson} />
        <button className={btn} onClick={exportJson}>Simpan JSON</button>
        <button className={btn} onClick={reset}>Reset</button>
        <button className="rounded-md bg-teal-700 px-3 py-1.5 text-[13px] font-medium text-white hover:bg-teal-800" onClick={downloadPdf} disabled={pdfBusy}>{pdfBusy ? "Membuat PDF..." : "Unduh PDF"}</button>
        <button className={btn} onClick={() => window.print()}>Cetak</button>
      </div>

      <div className="flex gap-1.5 border-b border-neutral-300 bg-neutral-50 px-3.5 py-2 dark:border-neutral-800 dark:bg-neutral-900 md:hidden print:hidden">
        <button className={tabCls(tab === "edit")} onClick={() => setTab("edit")}>Edit</button>
        <button className={tabCls(tab === "pv")} onClick={() => setTab("pv")}>Preview</button>
      </div>

      <main className="md:grid md:h-[calc(100vh-97px)] md:grid-cols-[minmax(340px,440px)_1fr] print:block print:h-auto">
        <div className={(tab === "edit" ? "block" : "hidden") + " h-[calc(100vh-150px)] overflow-auto border-r border-neutral-300 bg-neutral-50 dark:border-neutral-800 dark:bg-neutral-900 md:block md:h-full print:hidden"}>
          <div className="sticky top-0 z-10 flex gap-1.5 bg-neutral-50 px-3.5 pt-3 dark:bg-neutral-900">
            {[["isi", "Isi CV"], ["tampil", "Desain"], ["ats", "Cek ATS"]].map(([k, l]) => (
              <button key={k} className={tabCls(panel === k)} onClick={() => setPanel(k)}>{l}</button>
            ))}
          </div>
          {panel === "isi" && <Editor cv={cv} setCv={setCv} upd={upd} />}
          {panel === "tampil" && <Settings cv={cv} setCv={setCv} />}
          {panel === "ats" && <AtsChecker cv={cv} upd={upd} />}
          <p className="px-3.5 pb-4 text-xs text-neutral-500">Vitae by AWRcode Studio</p>
        </div>
        <div className={(tab === "pv" ? "block" : "hidden") + " h-[calc(100vh-150px)] md:block md:h-full print:block print:h-auto"}>
          <Sheet cv={cv} />
        </div>
      </main>
    </>
  );
}
