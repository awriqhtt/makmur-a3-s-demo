"use client";
import Link from "next/link";
import Portfolio from "../../components/Portfolio";
import { useCv } from "../../lib/useCv";

const btn = "rounded-md border border-neutral-300 bg-white px-2.5 py-1.5 text-[13px] font-medium hover:border-teal-600 dark:border-neutral-700 dark:bg-neutral-800";

export default function PortfolioPreview() {
  const { cv, name } = useCv();

  const download = (blob, file) => { const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = file; a.click(); };
  const slug = name.replace(/[^\w-]+/g, "_");

  /* Ambil HTML hasil render di halaman ini (sudah termasuk CSS) menjadi satu file mandiri */
  const html = () => {
    const main = document.querySelector("main.pf");
    const esc = (t) => t.replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
    const doc = `<!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>${esc(cv.profile.name)} - Portofolio</title></head><body style="margin:0">${main.outerHTML}</body></html>`;
    download(new Blob([doc], { type: "text/html;charset=utf-8" }), `portofolio-${slug}.html`);
  };
  const json = () => download(new Blob([JSON.stringify(cv, null, 2)], { type: "application/json" }), "portfolio.json");

  return (
    <>
      <div className="sticky top-0 z-10 flex flex-wrap items-center gap-2 border-b border-neutral-300 bg-neutral-50 px-3.5 py-2.5 dark:border-neutral-800 dark:bg-neutral-900">
        <h1 className="mr-auto text-[17px] font-semibold">Portofolio: {name}</h1>
        <Link href="/" className={btn}>Kembali ke CV</Link>
        <button className={btn} onClick={html}>Unduh HTML mandiri</button>
        <button className={btn} onClick={json}>Unduh portfolio.json</button>
      </div>
      <Portfolio cv={cv} />
    </>
  );
}
