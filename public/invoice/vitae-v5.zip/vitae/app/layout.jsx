import "./globals.css";
import { GFONTS_URL } from "../lib/design";

export const metadata = { title: "Vitae - CV & portofolio", description: "Buat CV dan portofolio dalam satu tempat" };

export default function RootLayout({ children }) {
  return (
    <html lang="id">
      <head><link rel="stylesheet" href={GFONTS_URL} /></head>
      <body className="font-sans text-[15px] antialiased">{children}</body>
    </html>
  );
}
