"use client";
import { useEffect, useState } from "react";
import Sheet from "../../components/Sheet";
import { norm } from "../../lib/useCv";

/* Halaman khusus untuk Puppeteer: data CV disuntikkan lewat window.__CV__ */
export default function PrintPage() {
  const [cv, setCv] = useState(null);
  useEffect(() => { if (window.__CV__) setCv(norm(window.__CV__)); }, []);
  if (!cv) return null;
  return (<><Sheet cv={cv} /><div id="ready" /></>);
}
