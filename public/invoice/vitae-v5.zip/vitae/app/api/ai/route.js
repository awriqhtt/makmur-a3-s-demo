const PROMPTS = {
  summary: "Tulis ulang ringkasan profil CV ini menjadi 2-3 kalimat yang padat dan profesional. Jangan mengarang fakta atau angka.",
  bullets: "Perbaiki poin pengalaman CV ini: satu poin per baris, mulai dengan kata kerja aksi, ringkas, dan jelas hasilnya. Jangan mengarang angka atau fakta yang tidak ada. Keluarkan hanya poin-poinnya tanpa simbol bullet.",
  cover: "Tulis isi surat lamaran kerja (tanpa salam pembuka dan penutup 'Hormat saya') berdasarkan CV dan lowongan yang diberikan. 3 paragraf pendek, spesifik, tidak mengarang fakta.",
};

export async function POST(req) {
  const key = process.env.ANTHROPIC_API_KEY;
  if (!key) return Response.json({ error: "ANTHROPIC_API_KEY belum diisi di .env.local" }, { status: 400 });
  const { task, text, context } = await req.json();
  if (!PROMPTS[task] || !text) return Response.json({ error: "Permintaan tidak valid" }, { status: 400 });
  const r = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "content-type": "application/json", "x-api-key": key, "anthropic-version": "2023-06-01" },
    body: JSON.stringify({
      model: process.env.ANTHROPIC_MODEL || "claude-sonnet-5-5",
      max_tokens: 900,
      system: PROMPTS[task] + " Balas dalam bahasa yang sama dengan teks input. Keluarkan hasil saja, tanpa pembuka atau penjelasan.",
      messages: [{ role: "user", content: (context ? "Konteks: " + context + "\n\n" : "") + text }],
    }),
  });
  const d = await r.json();
  if (!r.ok) return Response.json({ error: d?.error?.message || "Error dari API" }, { status: 502 });
  return Response.json({ text: (d.content || []).map((c) => c.text || "").join("").trim() });
}
