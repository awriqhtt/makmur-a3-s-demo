export const runtime = "nodejs";
export const maxDuration = 60;

/* Render halaman /print dengan Chromium headless lalu kembalikan sebagai PDF A4.
   Teks tetap berupa teks (bukan gambar), jadi ramah ATS. */
export async function POST(req) {
  let browser;
  try {
    const cv = await req.json();
    const puppeteer = (await import("puppeteer")).default;
    browser = await puppeteer.launch({ headless: true, args: ["--no-sandbox", "--disable-setuid-sandbox"] });
    const page = await browser.newPage();
    await page.setViewport({ width: 1280, height: 1600 });
    await page.evaluateOnNewDocument((d) => { window.__CV__ = d; }, cv);
    await page.goto(new URL(req.url).origin + "/print", { waitUntil: "load" });
    await page.waitForSelector("#ready", { timeout: 20000 });
    await page.evaluate(() => document.fonts.ready);
    const pdf = await page.pdf({ preferCSSPageSize: true, printBackground: true });
    return new Response(pdf, { headers: { "content-type": "application/pdf", "content-disposition": 'attachment; filename="cv.pdf"' } });
  } catch (e) {
    const msg = String(e?.message || e);
    return Response.json({ error: /Cannot find|Could not find|MODULE_NOT_FOUND/i.test(msg) ? "Puppeteer/Chromium belum terpasang. Jalankan npm install lagi." : "Gagal membuat PDF: " + msg }, { status: 500 });
  } finally {
    await browser?.close();
  }
}
