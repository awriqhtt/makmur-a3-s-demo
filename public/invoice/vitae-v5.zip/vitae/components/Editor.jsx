"use client";
import { useState } from "react";
import { askAi } from "../lib/ai";
import { SEC } from "../lib/data";

const box = "mt-1 w-full rounded-md border border-neutral-300 bg-white px-2.5 py-1.5 text-sm text-neutral-900 dark:border-neutral-700 dark:bg-neutral-800 dark:text-neutral-100";
const btn = "rounded-md border border-neutral-300 bg-white px-2.5 py-1 text-xs font-medium hover:border-teal-600 dark:border-neutral-700 dark:bg-neutral-800";

function Field({ label, value, onChange, kind, ai, ctx }) {
  const [busy, setBusy] = useState(false);
  const run = async () => {
    setBusy(true);
    try { onChange(await askAi(ai, value, ctx)); } catch (e) { alert(e.message); }
    setBusy(false);
  };
  return (
    <label className="mt-2 block text-xs text-neutral-500">
      {label}
      {kind === "a" ? (
        <textarea className={box + " min-h-[70px] resize-y"} value={value ?? ""} onChange={(e) => onChange(e.target.value)} />
      ) : kind === "c" ? (
        <input type="color" className="mt-1 block h-8 w-16 p-0.5" value={value} onChange={(e) => onChange(e.target.value)} />
      ) : kind === "n" ? (
        <input type="number" min={1} max={5} className={box} value={value}
          onChange={(e) => onChange(Math.min(5, Math.max(1, +e.target.value || 1)))} />
      ) : (
        <input type="text" className={box} value={value ?? ""} onChange={(e) => onChange(e.target.value)} />
      )}
      {ai && (
        <button type="button" disabled={busy || !value} onClick={run}
          className="mt-1 rounded-md border border-teal-600 px-2 py-0.5 text-xs text-teal-700 disabled:opacity-40 dark:text-teal-300">
          {busy ? "Memproses..." : "Perbaiki dengan AI"}
        </button>
      )}
    </label>
  );
}

function Group({ title, children }) {
  return (
    <fieldset className="mb-4 rounded-lg border border-neutral-300 px-3 pb-3 pt-1 dark:border-neutral-700">
      <legend className="px-1.5 text-sm font-semibold">{title}</legend>
      {children}
    </fieldset>
  );
}

export default function Editor({ cv, setCv, upd }) {
  const p = cv.profile;
  const [drag, setDrag] = useState(null);
  const reorder = (sec, from, to) => from !== to && setCv((c) => { const n = structuredClone(c), [x] = n[sec].splice(from, 1); n[sec].splice(to, 0, x); return n; });

  const mutate = (fn) => setCv((c) => { const n = structuredClone(c); fn(n); return n; });
  const add = (s) => mutate((n) => n[s].push({ ...SEC[s].b }));
  const del = (s, i) => confirm("Hapus item ini?") && mutate((n) => n[s].splice(i, 1));
  const move = (s, i, d) => mutate((n) => {
    const j = i + d;
    if (j < 0 || j >= n[s].length) return;
    [n[s][i], n[s][j]] = [n[s][j], n[s][i]];
  });

  const onPhoto = (e) => {
    const f = e.target.files[0];
    if (!f) return;
    const img = new Image(), url = URL.createObjectURL(f);
    img.onload = () => {
      const c = document.createElement("canvas"), n = 360, m = Math.min(img.width, img.height);
      c.width = c.height = n;
      c.getContext("2d").drawImage(img, (img.width - m) / 2, (img.height - m) / 2, m, m, 0, 0, n, n);
      upd("profile.photo", c.toDataURL("image/jpeg", 0.85));
      URL.revokeObjectURL(url);
    };
    img.src = url;
    e.target.value = "";
  };

  return (
    <div className="p-3.5">
      <Group title="Profil">
        <div className="mt-2 flex items-center gap-2">
          <label className={btn + " cursor-pointer"}>
            {p.photo ? "Ganti foto" : "Upload foto"}
            <input type="file" accept="image/*" hidden onChange={onPhoto} />
          </label>
          {p.photo && <button className={btn} onClick={() => upd("profile.photo", "")}>Hapus foto</button>}
        </div>
        <Field label="Nama" value={p.name} onChange={(v) => upd("profile.name", v)} />
        <Field label="Judul / posisi" value={p.title} onChange={(v) => upd("profile.title", v)} />
        <Field label="Email" value={p.email} onChange={(v) => upd("profile.email", v)} />
        <Field label="Telepon" value={p.phone} onChange={(v) => upd("profile.phone", v)} />
        <Field label="LinkedIn / website" value={p.link} onChange={(v) => upd("profile.link", v)} />
        <Field label="Lokasi" value={p.location} onChange={(v) => upd("profile.location", v)} />
        <Field label="Ringkasan" kind="a" ai="summary" ctx={p.title} value={p.summary} onChange={(v) => upd("profile.summary", v)} />
        <Field label="Warna aksen" kind="c" value={cv.accent} onChange={(v) => upd("accent", v)} />
      </Group>

      <Group title="Keahlian">
        <Field label="Pisahkan dengan koma" kind="a" value={cv.skills} onChange={(v) => upd("skills", v)} />
      </Group>

      {Object.entries(SEC).map(([s, c]) => (
        <Group key={s} title={c.t}>
          {cv[s].map((item, i) => (
            <div key={i} data-item
              className={"mt-2.5 border-t border-dashed border-neutral-300 pt-1 first:mt-0 first:border-0 dark:border-neutral-700 " + (drag && drag.s === s && drag.i !== i ? "bg-teal-50/60 dark:bg-teal-950/30" : "")}
              onDragOver={(e) => drag?.s === s && e.preventDefault()}
              onDrop={() => { if (drag?.s === s) reorder(s, drag.i, i); setDrag(null); }}>
              {c.f.map(([k, label, kind, ai]) => (
                <Field key={k} label={label} kind={kind} ai={ai} ctx={p.title} value={item[k]} onChange={(v) => upd(`${s}.${i}.${k}`, v)} />
              ))}
              <div className="mt-2 flex items-center gap-1.5">
                <span draggable title="Seret untuk memindah" className="cursor-grab select-none px-1 text-neutral-400"
                  onDragStart={(e) => { e.dataTransfer.setData("text/plain", "x"); e.dataTransfer.setDragImage(e.currentTarget.closest("[data-item]"), 0, 0); setDrag({ s, i }); }}
                  onDragEnd={() => setDrag(null)}>⠿</span>
                <label className="mr-auto flex items-center gap-1.5 text-xs">
                  <input type="checkbox" checked={item.show} onChange={(e) => upd(`${s}.${i}.show`, e.target.checked)} /> Tampilkan
                </label>
                <button className={btn} aria-label="Naik" onClick={() => move(s, i, -1)}>↑</button>
                <button className={btn} aria-label="Turun" onClick={() => move(s, i, 1)}>↓</button>
                <button className={btn} onClick={() => del(s, i)}>Hapus</button>
              </div>
            </div>
          ))}
          <button className={btn + " mt-3"} onClick={() => add(s)}>{c.add}</button>
        </Group>
      ))}
    </div>
  );
}
