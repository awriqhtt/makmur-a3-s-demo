"use client";
import { useState } from "react";
import { TITLES } from "../lib/data";
import { BGS, BULLETS, FONT_LIST, SWATCH, bgStyle, family } from "../lib/design";

const btn = "rounded-md border border-neutral-300 bg-white px-2 py-0.5 text-xs hover:border-teal-600 dark:border-neutral-700 dark:bg-neutral-800";
const sel = "mt-1 w-full rounded-md border border-neutral-300 bg-white px-2 py-1.5 text-sm text-neutral-900 dark:border-neutral-700 dark:bg-neutral-800 dark:text-neutral-100";

function Block({ title, children, ...rest }) {
  return (
    <fieldset className="mb-4 rounded-lg border border-neutral-300 px-3 pb-3 pt-1 dark:border-neutral-700" {...rest}>
      <legend className="px-1.5 text-xs font-semibold uppercase tracking-wide text-neutral-500">{title}</legend>
      {children}
    </fieldset>
  );
}

function Range({ label, value, min, max, step, onChange, lo, hi }) {
  return (
    <label className="mt-2 block text-xs text-neutral-500">
      {label}: <b className="text-neutral-800 dark:text-neutral-200">{value}</b>
      <input type="range" min={min} max={max} step={step} value={value} className="w-full accent-teal-700" onChange={(e) => onChange(+e.target.value)} />
      {lo && <span className="flex justify-between"><span>{lo}</span><span>{hi}</span></span>}
    </label>
  );
}

function Pick({ label, value, onChange }) {
  return (
    <label className="mt-2 flex items-center justify-between text-xs text-neutral-500">
      {label}
      <input type="color" className="h-7 w-10 p-0.5" value={value} onChange={(e) => onChange(e.target.value)} />
    </label>
  );
}

function Seg({ opts, value, onChange }) {
  return (
    <div className="mt-1 flex gap-1.5">
      {opts.map(([v, l]) => (
        <button key={v} onClick={() => onChange(v)}
          className={"flex-1 rounded-md border px-2 py-1 text-xs " + (value === v ? "border-teal-700 bg-teal-700 text-white" : "border-neutral-300 dark:border-neutral-700")}>{l}</button>
      ))}
    </div>
  );
}

/* Miniatur tata letak kolom */
const THUMB = {
  "1": [[4, 4, 32, 44]],
  "2L": [[4, 4, 21, 44], [28, 4, 8, 44]],
  "2R": [[4, 4, 8, 44], [15, 4, 21, 44]],
  side: [[4, 4, 11, 44, 1], [18, 4, 18, 44]],
};
function Thumb({ id, on, onClick, label }) {
  return (
    <button aria-label={label} title={label} onClick={onClick}
      className={"rounded-md border-2 bg-white p-1 " + (on ? "border-teal-600" : "border-neutral-300")}>
      <svg viewBox="0 0 40 52" className="h-14 w-full">
        {THUMB[id].map(([x, y, w, h, f], i) => <rect key={i} x={x} y={y} width={w} height={h} rx="1.5" fill={f ? "#14b8a6" : "#cbd5e1"} />)}
      </svg>
    </button>
  );
}

export default function Settings({ cv, setCv }) {
  const [drag, setDrag] = useState(null);
  const d = cv.design, L = cv.layout;
  const mut = (fn) => setCv((c) => { const n = structuredClone(c); fn(n); return n; });
  const set = (k, v) => mut((n) => { n.design[k] = v; });
  const move = (col, i, dir) => mut((n) => {
    const a = n.layout[col], j = i + dir;
    if (j < 0 || j >= a.length) return;
    [a[i], a[j]] = [a[j], a[i]];
  });
  const shift = (col, i) => mut((n) => { const [id] = n.layout[col].splice(i, 1); n.layout[col === "left" ? "right" : "left"].push(id); });
  const toggle = (id) => mut((n) => { const h = n.layout.hidden, k = h.indexOf(id); k < 0 ? h.push(id) : h.splice(k, 1); });
  const drop = (col, j) => {
    if (!drag) return;
    mut((n) => {
      const [id] = n.layout[drag.col].splice(drag.i, 1), dst = n.layout[col];
      let k = j == null ? dst.length : j;
      if (drag.col === col && j != null && drag.i < j) k = j - 1;
      dst.splice(k, 0, id);
    });
    setDrag(null);
  };

  return (
    <div className="p-3.5 text-sm">
      <Block title="Gaya">
        <Seg value={d.style} onChange={(v) => set("style", v)} opts={[["modern", "Modern"], ["minimal", "Minimalis"], ["ats", "ATS polos"]]} />
        <p className="mt-1.5 text-xs text-neutral-500">ATS polos: tanpa foto, ikon, titik bahasa, dan pola latar.</p>
      </Block>

      <Block title="Tata letak kolom">
        <div className="grid grid-cols-4 gap-2">
          <Thumb id="1" label="Satu kolom" on={d.cols === "1"} onClick={() => set("cols", "1")} />
          <Thumb id="2L" label="Dua kolom, utama di kiri" on={d.cols === "2L"} onClick={() => set("cols", "2L")} />
          <Thumb id="2R" label="Dua kolom, utama di kanan" on={d.cols === "2R"} onClick={() => set("cols", "2R")} />
          <Thumb id="side" label="Sidebar berwarna" on={d.cols === "side"} onClick={() => set("cols", "side")} />
        </div>
      </Block>

      <Block title="Margin & jarak">
        <Range label="Margin halaman (mm)" value={d.margin} min={8} max={24} step={1} onChange={(v) => set("margin", v)} lo="sempit" hi="lebar" />
        <Range label="Jarak antar section" value={d.gap} min={0.5} max={2} step={0.1} onChange={(v) => set("gap", +v.toFixed(1))} lo="rapat" hi="lega" />
      </Block>

      <Block title="Warna">
        <div className="mt-2 grid grid-cols-5 gap-2">
          {SWATCH.map((c) => (
            <button key={c} aria-label={c} onClick={() => mut((n) => { n.accent = c; })} style={{ background: c }}
              className={"h-8 rounded-full border-2 border-white outline outline-2 " + (cv.accent === c ? "outline-neutral-900 dark:outline-white" : "outline-transparent")} />
          ))}
        </div>
        <Pick label="Warna aksen kustom" value={cv.accent} onChange={(v) => mut((n) => { n.accent = v; })} />
        <Pick label="Warna teks" value={d.textColor} onChange={(v) => set("textColor", v)} />
        <Pick label="Warna judul section" value={d.headingColor} onChange={(v) => set("headingColor", v)} />
        <Pick label="Warna nama" value={d.nameColor} onChange={(v) => set("nameColor", v)} />
      </Block>

      <Block title="Font">
        <label className="mt-2 block text-xs text-neutral-500">Gaya font
          <select className={sel} style={{ fontFamily: family(d.font) }} value={d.font} onChange={(e) => set("font", e.target.value)}>
            {FONT_LIST.map((f) => <option key={f.id} value={f.id} style={{ fontFamily: family(f.id) }}>{f.l}</option>)}
          </select>
        </label>
        <Range label="Ukuran font (pt)" value={d.size} min={8} max={11.5} step={0.5} onChange={(v) => set("size", v)} lo="extra kecil" hi="besar" />
        <Range label="Tinggi baris" value={d.lh} min={1.2} max={1.8} step={0.05} onChange={(v) => set("lh", +v.toFixed(2))} lo="rapat" hi="lega" />
      </Block>

      <Block title="Header (nama & subjudul)">
        <Range label="Ukuran nama" value={d.nameSize} min={1.8} max={3.4} step={0.1} onChange={(v) => set("nameSize", +v.toFixed(1))} />
        <Range label="Ukuran subjudul" value={d.subSize} min={0.9} max={1.6} step={0.05} onChange={(v) => set("subSize", +v.toFixed(2))} />
        <div className="mt-2 text-xs text-neutral-500">Huruf nama</div>
        <Seg value={d.nameCase} onChange={(v) => set("nameCase", v)} opts={[["upper", "KAPITAL"], ["normal", "Normal"]]} />
        <div className="mt-2 text-xs text-neutral-500">Perataan header</div>
        <Seg value={d.align} onChange={(v) => set("align", v)} opts={[["left", "Kiri"], ["center", "Tengah"]]} />
        <div className="mt-2 text-xs text-neutral-500">Huruf judul section</div>
        <Seg value={d.headCase} onChange={(v) => set("headCase", v)} opts={[["upper", "KAPITAL"], ["normal", "Normal"]]} />
      </Block>

      <Block title="Ikon bullet">
        <div className="mt-2 grid grid-cols-7 gap-1.5">
          {BULLETS.map((b) => (
            <button key={b.id} onClick={() => set("bullet", b.id)} title={b.id}
              className={"rounded-md border px-1 py-1.5 text-sm " + (d.bullet === b.id ? "border-teal-700 bg-teal-700 text-white" : "border-neutral-300 dark:border-neutral-700")}>{b.id === "none" ? "∅" : b.l}</button>
          ))}
        </div>
      </Block>

      <Block title="Latar belakang">
        <div className="mt-2 grid grid-cols-4 gap-2">
          {BGS.map((b) => (
            <button key={b.id} title={b.l} aria-label={b.l} onClick={() => set("bg", b.id)}
              style={{ backgroundColor: "#fff", ...bgStyle(b.id, cv.accent) }}
              className={"h-14 rounded-md border-2 " + (d.bg === b.id ? "border-teal-600" : "border-neutral-300")} />
          ))}
        </div>
      </Block>

      {["left", "right"].map((col) => (
        <Block key={col} title={d.cols === "side" ? (col === "left" ? "Konten utama" : "Sidebar") : col === "left" ? "Section utama (kiri)" : "Section samping (kanan)"}
          onDragOver={(e) => drag && e.preventDefault()} onDrop={() => drop(col, null)}>
          {L[col].map((id, i) => (
            <div key={id} className="mt-2 flex items-center gap-1.5" onDragOver={(e) => drag && e.preventDefault()}
              onDrop={(e) => { e.stopPropagation(); drop(col, i); }}>
              <span draggable title="Seret untuk memindah" className="cursor-grab select-none px-1 text-neutral-400"
                onDragStart={(e) => { e.dataTransfer.setData("text/plain", id); setDrag({ col, i }); }} onDragEnd={() => setDrag(null)}>⠿</span>
              <label className="mr-auto flex items-center gap-1.5">
                <input type="checkbox" checked={!L.hidden.includes(id)} onChange={() => toggle(id)} /> {TITLES[id]}
              </label>
              <button className={btn} aria-label="Naik" onClick={() => move(col, i, -1)}>↑</button>
              <button className={btn} aria-label="Turun" onClick={() => move(col, i, 1)}>↓</button>
              <button className={btn} onClick={() => shift(col, i)}>{col === "left" ? "→" : "←"}</button>
            </div>
          ))}
        </Block>
      ))}
      <p className="text-xs text-neutral-500">Seret ⠿ untuk memindah section. Pada satu kolom, kedua daftar digabung berurutan.</p>
    </div>
  );
}
