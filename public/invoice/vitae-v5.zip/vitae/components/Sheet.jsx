"use client";
import { useEffect, useRef, useState } from "react";
import { TITLES } from "../lib/data";
import { BULLETS, bgStyle, family } from "../lib/design";

const ICONS = ["↗", "★", "$", "✓"];
const lines = (t) => String(t || "").split("\n").map((x) => x.trim()).filter(Boolean);
const shown = (l = []) => l.filter((e) => e.show);
const dateLoc = (e) => [e.period, e.loc].filter(Boolean).join(" | ");

function Sec({ t, children, kind, upper }) {
  if (!children || (Array.isArray(children) && !children.length)) return null;
  const min = kind === "minimal";
  return (
    <section>
      <h3 className={"mb-2 text-[var(--hc)] first:mt-0 " + (upper ? "uppercase " : "") + (min
        ? "mt-[calc(1.3em*var(--gap))] border-b border-neutral-300 pb-1 text-[0.95em] font-semibold tracking-[0.18em]"
        : "mt-[calc(0.95em*var(--gap))] border-b-2 border-[var(--hc)] pb-0.5 text-[1.15em] font-extrabold")}>{t}</h3>
      {children}
    </section>
  );
}

function Entry({ title, sub, meta, bullets = [], desc }) {
  return (
    <div className="mb-[calc(0.5em*var(--gap))] break-inside-avoid">
      <div className="font-bold">{title}</div>
      {sub && <div className="font-bold text-[var(--a)]">{sub}</div>}
      {meta && <div className="text-[0.9em] text-neutral-500">{meta}</div>}
      {bullets.length > 0 && <ul className="ml-4 mt-1" style={{ listStyleType: "var(--bl)" }}>{bullets.map((b, j) => <li key={j}>{b}</li>)}</ul>}
      {desc && <p className="mt-0.5">{desc}</p>}
    </div>
  );
}

const R = {
  summary: (cv) => cv.profile.summary && <p>{cv.profile.summary}</p>,
  exp: (cv) => shown(cv.exp).map((e, i) => <Entry key={i} title={e.role} sub={e.org} meta={dateLoc(e)} bullets={lines(e.bullets)} />),
  edu: (cv) => shown(cv.edu).map((e, i) => <Entry key={i} title={e.degree} sub={e.school} meta={dateLoc(e)} />),
  proj: (cv) => shown(cv.proj).map((e, i) => <Entry key={i} title={e.name} sub={e.link} meta={e.period} desc={e.desc} />),
  cert: (cv) => shown(cv.cert).map((e, i) => <Entry key={i} title={e.name} sub={e.issuer} meta={e.period} />),
  award: (cv) => shown(cv.award).map((e, i) => <Entry key={i} title={e.name} sub={e.issuer} meta={e.period} desc={e.desc} />),
  org: (cv) => shown(cv.org).map((e, i) => <Entry key={i} title={e.role} sub={e.org} meta={e.period} desc={e.desc} />),
  skills: (cv, plain) => {
    const sk = String(cv.skills || "").split(",").map((x) => x.trim()).filter(Boolean);
    if (!sk.length) return null;
    return plain ? <p>{sk.join(", ")}</p> : (
      <div className="tags flex flex-wrap gap-1.5">
        {sk.map((s) => <span key={s} className="border-b-[1.5px] border-neutral-400 bg-neutral-100 px-2 py-0.5 text-[0.9em]">{s}</span>)}
      </div>
    );
  },
  ach: (cv, plain) => shown(cv.ach).map((e, i) => (
    <div key={i} className="flex break-inside-avoid gap-2 border-b border-dashed border-neutral-400 py-1.5">
      {!plain && <i className="w-4 flex-none text-center text-[1.25em] font-extrabold not-italic text-[var(--a)]">{ICONS[i % 4]}</i>}
      <div><b className="block">{e.title}</b>{e.desc}</div>
    </div>
  )),
  langs: (cv, plain) => shown(cv.langs).map((e, i) => (
    <div key={i} className="mb-2 flex items-center justify-between">
      <div><b className="block">{e.name}</b><small className="text-neutral-500">{e.level}</small></div>
      {!plain && (
        <div className="dots flex gap-[3px]">
          {[0, 1, 2, 3, 4].map((d) => <span key={d} className={"h-[11px] w-[11px] rounded-full " + (d < e.dots ? "on bg-[var(--a)]" : "bg-neutral-300")} />)}
        </div>
      )}
    </div>
  )),
};

export default function Sheet({ cv }) {
  const wrap = useRef(null), sheet = useRef(null);
  const [z, setZ] = useState(1);
  const [pages, setPages] = useState(1);
  const d = cv.design, L = cv.layout, p = cv.profile;
  const ats = d.style === "ats", min = d.style === "minimal", plain = ats || min;
  const side = d.cols === "side", center = d.align === "center";
  const hc = min && d.headingColor === "#171717" ? cv.accent : d.headingColor;
  const m = d.margin;

  useEffect(() => {
    const fit = () => setZ(Math.min(1, Math.max(0.3, (wrap.current.clientWidth - 24) / 794)));
    fit();
    const ro = new ResizeObserver(fit);
    ro.observe(wrap.current);
    return () => ro.disconnect();
  }, []);

  useEffect(() => {
    const s = sheet.current;
    setPages(Math.max(1, Math.ceil((s.offsetHeight / s.offsetWidth) / (297 / 210) - 0.02)));
  }, [cv, z]);

  const render = (ids) => ids.filter((id) => !L.hidden.includes(id)).map((id) => (
    <Sec key={id} t={TITLES[id]} kind={d.style} upper={d.headCase === "upper"}>{R[id](cv, plain)}</Sec>
  ));
  const contacts = [p.phone, p.email, p.link, p.location].filter(Boolean);

  const heading = (
    <div className={center && !side ? "w-full text-center" : ""}>
      <h1 className="font-extrabold leading-none"
        style={{ fontSize: `${d.nameSize}em`, color: d.nameColor, textTransform: d.nameCase === "upper" ? "uppercase" : "none" }}>{p.name}</h1>
      <div className="mt-1 font-bold text-[var(--a)]" style={{ fontSize: `${d.subSize}em` }}>{p.title}</div>
      {!side && (
        <div className={"mt-2 flex flex-wrap gap-x-4 gap-y-1 text-[0.9em] font-semibold " + (center ? "justify-center" : "")}>
          {contacts.map((x) => <span key={x}>{x}</span>)}
        </div>
      )}
    </div>
  );

  const style = {
    zoom: String(z), "--a": cv.accent, "--hc": hc, "--gap": d.gap, "--bl": (BULLETS.find((b) => b.id === d.bullet) || BULLETS[0]).css,
    fontFamily: family(d.font), fontSize: `${d.size}pt`, lineHeight: d.lh, color: d.textColor,
    backgroundColor: "#fff", ...bgStyle(ats ? "none" : d.bg, cv.accent),
    ...(side ? {} : { padding: `${m * 0.9}mm ${m}mm` }),
  };
  const narrowFirst = d.cols === "2R";

  return (
    <div ref={wrap} className="h-full overflow-auto p-3 md:p-6 print:overflow-visible print:p-0">
      <p className="mb-2 text-center text-xs text-neutral-500 print:hidden">
        {pages} halaman A4{pages > 2 ? " (disarankan maksimal 2 halaman)" : ""}
      </p>
      <div id="sheet" ref={sheet} style={style} className="mx-auto min-h-[297mm] w-[210mm] shadow-xl">
        {side ? (
          <div className="grid min-h-[297mm] grid-cols-[63mm_1fr]">
            <aside className="side-inv bg-[var(--a)]" style={{ padding: `${m * 0.9}mm ${m * 0.5}mm` }}>
              {p.photo && !ats && <img src={p.photo} alt="Foto profil" className="mx-auto mb-4 h-[36mm] w-[36mm] rounded-full object-cover" />}
              <div className="mb-2 space-y-1 break-words text-[0.9em] font-semibold">{contacts.map((x) => <div key={x}>{x}</div>)}</div>
              {render(L.right)}
            </aside>
            <div style={{ padding: `${m * 0.9}mm ${m * 0.7}mm` }}>
              <div className="mb-3">{heading}</div>
              {render(L.left)}
            </div>
          </div>
        ) : (
          <>
            <header className="mb-3 flex items-center justify-between gap-4">
              {heading}
              {p.photo && !ats && <img src={p.photo} alt="Foto profil" className="h-[26mm] w-[26mm] flex-none rounded-full object-cover" />}
            </header>
            {d.cols === "1" ? (
              <div>{render([...L.left, ...L.right])}</div>
            ) : (
              <div className={"grid gap-x-[9mm] " + (narrowFirst ? "grid-cols-[1fr_1.18fr]" : "grid-cols-[1.18fr_1fr]")}>
                <div>{render(narrowFirst ? L.right : L.left)}</div>
                <div>{render(narrowFirst ? L.left : L.right)}</div>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
