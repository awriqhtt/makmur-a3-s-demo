"use client";
import { useMemo } from "react";
import { cvText } from "../lib/text";

const STOP = new Set(("yang dan di ke dari untuk dengan pada adalah atau akan dalam ini itu sebagai kami anda kita juga serta dapat oleh saat " +
  "the and for with you our are will have has this that from your their to of in a an be as on at by or we is it can all any not who job work team").split(" "));

function keywords(t) {
  const m = {};
  (t.toLowerCase().match(/[a-z0-9+#.]{3,}/g) || []).forEach((w) => {
    w = w.replace(/\.+$/, "");
    if (w.length > 2 && !STOP.has(w) && !/^\d+$/.test(w)) m[w] = (m[w] || 0) + 1;
  });
  return Object.entries(m).sort((a, b) => b[1] - a[1]).slice(0, 30).map((x) => x[0]);
}

export default function AtsChecker({ cv, upd }) {
  const jd = cv.letter.jd;
  const res = useMemo(() => {
    if (!jd.trim()) return null;
    const text = cvText(cv).toLowerCase(), ks = keywords(jd);
    const found = ks.filter((k) => text.includes(k));
    return { found, missing: ks.filter((k) => !text.includes(k)), pct: ks.length ? Math.round((found.length / ks.length) * 100) : 0 };
  }, [cv, jd]);

  return (
    <div className="p-3.5 text-sm">
      <label className="block text-xs text-neutral-500">Tempel deskripsi lowongan (juga dipakai di Surat lamaran)
        <textarea className="mt-1 min-h-[160px] w-full rounded-md border border-neutral-300 bg-white p-2.5 text-sm text-neutral-900 dark:border-neutral-700 dark:bg-neutral-800 dark:text-neutral-100"
          value={jd} onChange={(e) => upd("letter.jd", e.target.value)} />
      </label>
      {res && (
        <div className="mt-3">
          <div className="text-base font-semibold">Kecocokan kata kunci: {res.pct}%</div>
          <p className="mt-2 text-xs text-neutral-500">Sudah ada di CV</p>
          <div className="mt-1 flex flex-wrap gap-1">{res.found.map((k) => <span key={k} className="rounded bg-teal-100 px-1.5 py-0.5 text-xs text-teal-900">{k}</span>)}</div>
          <p className="mt-3 text-xs text-neutral-500">Belum ada di CV (masukkan hanya yang memang kamu kuasai)</p>
          <div className="mt-1 flex flex-wrap gap-1">{res.missing.map((k) => <span key={k} className="rounded bg-amber-100 px-1.5 py-0.5 text-xs text-amber-900">{k}</span>)}</div>
        </div>
      )}
    </div>
  );
}
