import { PORTFOLIO_CSS } from "../lib/portfolioCss";

const shown = (l = []) => l.filter((e) => e.show);
const lines = (t) => String(t || "").split("\n").map((x) => x.trim()).filter(Boolean);
const href = (u) => (/^https?:\/\//i.test(u) ? u : "https://" + u);

function Block({ id, t, cv, children }) {
  if (cv.layout.hidden.includes(id) || !children || (Array.isArray(children) && !children.length)) return null;
  return <section><h2>{t}</h2>{children}</section>;
}

function Item({ title, sub, meta, bullets = [], desc }) {
  return (
    <div className="pf-item">
      <div className="pf-row"><span className="pf-t">{title}</span>{meta && <span className="pf-m">{meta}</span>}</div>
      {sub && <div className="pf-s">{sub}</div>}
      {bullets.length > 0 && <ul>{bullets.map((b, i) => <li key={i}>{b}</li>)}</ul>}
      {desc && <p style={{ margin: "4px 0 0" }}>{desc}</p>}
    </div>
  );
}

/* Komponen murni (tanpa hooks): dipakai di /portfolio, /p, dan ekspor HTML mandiri */
export default function Portfolio({ cv, inlineCss = true }) {
  const p = cv.profile, dl = (e) => [e.period, e.loc].filter(Boolean).join(" | ");
  const skills = String(cv.skills || "").split(",").map((x) => x.trim()).filter(Boolean);
  return (
    <main className="pf" style={{ "--a": cv.accent }}>
      {inlineCss && <style dangerouslySetInnerHTML={{ __html: PORTFOLIO_CSS }} />}
      <header className="pf-hero">
        {p.photo && <img className="pf-ph" src={p.photo} alt={"Foto " + p.name} />}
        <div>
          <h1>{p.name}</h1>
          <p className="pf-ttl">{p.title}</p>
          {p.summary && <p className="pf-sum">{p.summary}</p>}
          <div className="pf-ct">
            {p.email && <a href={"mailto:" + p.email}>{p.email}</a>}
            {p.phone && <span>{p.phone}</span>}
            {p.link && <a href={href(p.link)} rel="noopener noreferrer">{p.link}</a>}
            {p.location && <span>{p.location}</span>}
          </div>
        </div>
      </header>

      <Block id="exp" t="Pengalaman" cv={cv}>
        {shown(cv.exp).map((e, i) => <Item key={i} title={e.role} sub={e.org} meta={dl(e)} bullets={lines(e.bullets)} />)}
      </Block>
      <Block id="proj" t="Proyek" cv={cv}>
        {shown(cv.proj).length > 0 && (
          <div className="pf-grid">
            {shown(cv.proj).map((e, i) => (
              <div key={i} className="pf-card">
                <div className="pf-t">{e.name}</div>
                {e.period && <div className="pf-m">{e.period}</div>}
                {e.desc && <p>{e.desc}</p>}
                {e.link && <p><a href={href(e.link)} rel="noopener noreferrer">{e.link}</a></p>}
              </div>
            ))}
          </div>
        )}
      </Block>
      <Block id="ach" t="Pencapaian utama" cv={cv}>
        {shown(cv.ach).length > 0 && (
          <div className="pf-grid">
            {shown(cv.ach).map((e, i) => <div key={i} className="pf-card"><div className="pf-t">{e.title}</div><p>{e.desc}</p></div>)}
          </div>
        )}
      </Block>
      <Block id="skills" t="Keahlian" cv={cv}>
        {skills.length > 0 && <div className="pf-tags">{skills.map((s) => <span key={s}>{s}</span>)}</div>}
      </Block>
      <Block id="edu" t="Pendidikan" cv={cv}>
        {shown(cv.edu).map((e, i) => <Item key={i} title={e.degree} sub={e.school} meta={dl(e)} />)}
      </Block>
      <Block id="cert" t="Sertifikasi" cv={cv}>
        {shown(cv.cert).map((e, i) => <Item key={i} title={e.name} sub={e.issuer} meta={e.period} />)}
      </Block>
      <Block id="org" t="Organisasi & volunteer" cv={cv}>
        {shown(cv.org).map((e, i) => <Item key={i} title={e.role} sub={e.org} meta={e.period} desc={e.desc} />)}
      </Block>
      <Block id="award" t="Penghargaan" cv={cv}>
        {shown(cv.award).map((e, i) => <Item key={i} title={e.name} sub={e.issuer} meta={e.period} desc={e.desc} />)}
      </Block>
      <Block id="langs" t="Bahasa" cv={cv}>
        {shown(cv.langs).map((e, i) => (
          <div key={i} className="pf-item">
            <span className="pf-t">{e.name}</span> <span className="pf-m">{e.level}</span>
            <span className="pf-dots">{[0, 1, 2, 3, 4].map((d) => <i key={d} className={d < e.dots ? "on" : ""} />)}</span>
          </div>
        ))}
      </Block>
      <p className="pf-foot">{p.name}</p>
    </main>
  );
}
