# Vitae (vitae.cv)

Buat CV dan portofolio dalam satu tempat. Next.js + Tailwind. By AWRcode Studio.

Logo: `public/logo.svg`, `public/logo-white.svg` (untuk latar gelap), `public/logo-mark.svg`; favicon di `app/icon.svg`.

## Jalankan
```bash
npm install
npm run dev
```
Buka http://localhost:3000. Data tersimpan di localStorage browser.

## Fitur
- Panel Desain & font: 12 font Google Fonts, margin, jarak section, warna (aksen, teks, judul, nama), ukuran/huruf header, ikon bullet, 8 pola latar, 4 tata letak kolom, dan 3 gaya (Modern, Minimalis, ATS polos)
- Unduh PDF satu klik (Puppeteer) dan halaman portofolio (preview, HTML mandiri, halaman publik /p)
- Undo/redo (Ctrl+Z / Ctrl+Y) dan drag-and-drop untuk item dan section
- Preset warna aksen
- Section: ringkasan, pengalaman, pendidikan, proyek, sertifikasi, organisasi, keahlian, pencapaian, bahasa, penghargaan
- Atur tampil/sembunyi, urutan, dan kolom tiap section; atur font, ukuran, jarak baris, warna aksen
- Beberapa CV (baru, duplikat, ganti nama, hapus) untuk tiap target lowongan
- Cek ATS: tempel deskripsi lowongan, lihat kata kunci yang sudah dan belum ada
- Surat lamaran (/cover-letter) memakai data CV yang sama
- Perbaiki ringkasan/poin pengalaman dan tulis surat dengan AI (Claude)
- Indikator jumlah halaman, Simpan/Import JSON, Cetak ke PDF

## Fitur AI (opsional)
Salin `.env.example` menjadi `.env.local`, isi `ANTHROPIC_API_KEY`, lalu restart `npm run dev`.
Tanpa key, fitur lain tetap jalan. Key hanya dipakai di server (app/api/ai/route.js), tidak sampai ke browser.

## Ekspor PDF
Cetak / PDF, Save as PDF, A4, margin None, centang "Background graphics".

## Deploy
Push ke GitHub, import di Vercel, tambahkan ANTHROPIC_API_KEY di Environment Variables jika ingin AI.
Catatan: data tetap di browser pemakai, jadi simpan JSON secara berkala.

## Struktur
- app/page.jsx: toolbar, multi-CV, panel editor
- app/cover-letter/page.jsx: surat lamaran
- app/api/ai/route.js: proxy ke API Claude
- components/: Editor, Settings, AtsChecker, Sheet (template CV)
- lib/: data.js (data contoh + konfigurasi section), useCv.js (state), text.js, ai.js

## Unduh PDF (Puppeteer)
`npm install` ikut mengunduh Chromium (sekitar 170 MB) saat pertama kali. Tombol "Unduh PDF" memanggil /api/pdf,
yang membuka halaman /print dengan Chromium headless lalu menghasilkan PDF A4 (teks tetap bisa dibaca mesin).
Berjalan di komputer sendiri (`npm run dev` atau `npm start`). Di Vercel, Puppeteer biasa tidak jalan karena
ukuran Chromium; gunakan `puppeteer-core` + `@sparticuz/chromium`, atau pakai tombol "Cetak" bawaan browser.

## Portofolio
- /portfolio: preview dari CV aktif. Dari sini: "Unduh HTML mandiri" (satu file, bisa di-hosting di GitHub Pages/Netlify)
  atau "Unduh portfolio.json".
- /p: halaman publik di website ini. Salin portfolio.json ke `data/portfolio.json`, lalu deploy ulang.
  Karena data CV hanya ada di browser, halaman publik membaca dari file itu, bukan dari localStorage.
